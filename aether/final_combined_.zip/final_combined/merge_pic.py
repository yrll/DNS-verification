from PIL import Image

# 打开两张图片
try:
    image1 = Image.open('/home/matsu/final_draw_bdd_1.31/bar/burst/burst_setime.png')
    image2 = Image.open('/home/matsu/final_draw_bdd_1.31/bar/burst/ratio/cdf_burst_setime_ratio.png')
    # image3 = Image.open('/home/matsu/final_draw_bdd_1.31/incremental/ratio/cdf_incre_e2etime_ratio.png')

except FileNotFoundError as e:
    print(f"Error: {e}")
    exit()

# 获取图片的宽度和高度
width1, height1 = image1.size
width2, height2 = image2.size
# width3, height3 = image3.size

# 合并后的图片宽度和高度
combined_width = width1 + width2 
combined_height = max(height1, height2)

# 创建一个新的空白图片
new_image = Image.new('RGB', (combined_width, combined_height))

# 将两张图片粘贴到新图片上
new_image.paste(image1, (0, 0))  # 粘贴第一张图片
new_image.paste(image2, (width1, 0))  # 粘贴第二张图片
# new_image.paste(image3, (width1 + width2, 0))  # 粘贴第二张图片

# 保存合并后的图片为 PDF，设定保存路径
output_path = '/home/matsu/final_draw_bdd_1.31/combined/burst_setime_combined_image.pdf'
new_image.save(output_path, 'PDF')


# 显示合并后的图片（可选）
new_image.show()